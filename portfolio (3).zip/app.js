/* ============================================================
   Minimal interactivity — nav background on scroll, and a gentle
   reveal-on-scroll for sections. No frameworks needed.
   ============================================================ */

(function () {
  const nav = document.getElementById('nav');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 12) nav.style.boxShadow = '0 2px 24px rgba(0,0,0,0.3)';
    else nav.style.boxShadow = 'none';
  });

  // Reveal-on-scroll for sections and project cards
  const revealTargets = document.querySelectorAll('section, .project-card');
  revealTargets.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(16px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  });

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  revealTargets.forEach(el => observer.observe(el));

  // Respect reduced-motion preference
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    revealTargets.forEach(el => {
      el.style.transition = 'none';
      el.style.opacity = '1';
      el.style.transform = 'none';
    });
  }

  // "View code" buttons sit inside the project-card <a> (which links to the
  // live dashboard). Stop the click from bubbling to the card's own link,
  // then open the repo URL ourselves.
  document.querySelectorAll('.project-link-secondary[data-repo]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      window.open(btn.dataset.repo, '_blank', 'noopener');
    });
  });
})();
